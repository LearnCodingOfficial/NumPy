#!/usr/bin/env python
# coding: utf-8

# In[1]:


pip install numpy


# In[2]:


import numpy as np


# In[4]:


#creating an array
arr = np.array([1,2,3,4,5])
arr


# In[6]:


#creating a 0-D array
arrzero = np.array(80)
print(arrzero)


# In[9]:


#checking the dimension of the array
print(arr.ndim)
arrzero.ndim


# In[14]:


#creating a 2-D array
arr2 = np.array([[1,2,3,4,5],[7,8,9,10,11]])
print(arr2)
print(arr2.ndim)


# In[15]:


#number of elements
arr2.size


# In[16]:


#total memory taken by an array
arr2.nbytes


# In[17]:


arrzero.nbytes


# In[18]:


#single element size
#[[ 1  2  3  4  5]
#[ 7  8  9 10 11]]
arr2.itemsize


# In[19]:


#for the data type of the array
arr2.dtype


# In[20]:


print(arr2)
#[[ 1  2  3  4  5](Oth row)
#[ 7  8  9 10 11]](1st row row)


# In[21]:


#for the specific element of the array()
arr2[0,2]


# In[23]:


#specific row of the array
arr2[1,:]


# In[24]:


arr3 = np.array([1,2,3,4,5,6,7,8,9,10])
print(arr3)


# In[25]:


#(Start Index:Ending Index)[inclusive:exclusive]
arr3[1:5]


# In[29]:


print(arr3[5:])


# In[28]:


print(arr3[:5])


# In[30]:


print(arr2)


# In[31]:


print(arr2[1,1:4])


# In[32]:


#copying of an array
arr4 = arr2.copy()
print(arr4)


# In[33]:


#Zero matrix
np.zeros((4,6))


# In[37]:


#All 1 matrix
np.ones((6,3,3))


# In[40]:


#other matrix
np.full((40,40),678)


# In[41]:


#importing random
from numpy import random


# In[44]:


x = random.randint(100)
print(x)


# In[46]:


np.random.rand(4,4)


# In[48]:


#identity matrix
np.identity(6)


# In[50]:


#Mathematical operation on array
arrm = np.array([10,20,30,40])
print(arrm)


# In[55]:


#plus opertaion
arrm = arrm+15
arrm


# In[59]:


#subtraction operation
arrm = arrm - 40
print(arrm)


# In[61]:


arrz = arrm+100
arrz


# In[64]:


#multiplication operation
print(arrm)
arrm*10


# In[65]:


#Divison operation
arrm/7


# In[67]:


a1 = np.array([1,2,3,4,5])
a2 = np.array([10,15,20,25,30])
print(a1+a2)


# In[68]:


#cos function in an array
np.cos(a1)


# In[69]:


print(arr2)


# In[70]:


#minimum value from the array
np.min(arr2)


# In[71]:


#maximum value from the array
np.max(arr2)


# In[72]:


np.sum(arr2)


# In[73]:


#iterating in 1-D
for x in a1:
    print(x)


# In[74]:


#iterating in 2-D
for z in arr2:
    print(z)


# In[75]:


for a in arr2:
    for b in a:
        print(b)


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




